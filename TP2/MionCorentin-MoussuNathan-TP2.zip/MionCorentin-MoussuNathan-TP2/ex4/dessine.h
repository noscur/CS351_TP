void dessineCarre(int posx, int posy, int size);
void dessineCarre(int posx, int posy, int size);
void dessineMosaique(int taille_carre, int largeur, int hauteur, int posx, int posy);