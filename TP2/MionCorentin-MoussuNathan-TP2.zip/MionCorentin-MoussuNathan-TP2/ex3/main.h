int quotient(int a, int b); 
int reste(int a, int b);
int valeurAbsolue(int a);
int ppcm(int a, int b);
int puissanceMB(int x, int n);
int sommeDesImpairs(int d, int f);
int estUneDecompositionDe(int d, int f);
