int pgcd(int a,int b);

